declare module "@salesforce/apex/AP_CheckTVA.checkTVA" {
  export default function checkTVA(param: {accountId: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_CheckTVA.updateAccountVTA_Yes" {
  export default function updateAccountVTA_Yes(param: {accountId: any, LegalName: any, BillingAddress: any, tvaNumber: any, billingCountryCode: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_CheckTVA.updateAccountVTA_No" {
  export default function updateAccountVTA_No(param: {updateVAT: any, accountId: any}): Promise<any>;
}
