declare module "@salesforce/apex/AP_EditLead.getLeadStatus" {
  export default function getLeadStatus(param: {leadId: any}): Promise<any>;
}
