declare module "@salesforce/apex/AP_HereAPILocationSearch.getLocation" {
  export default function getLocation(param: {location: any}): Promise<any>;
}
