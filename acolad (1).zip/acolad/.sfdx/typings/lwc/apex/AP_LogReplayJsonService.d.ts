declare module "@salesforce/apex/AP_LogReplayJsonService.replayLog" {
  export default function replayLog(param: {logId: any}): Promise<any>;
}
