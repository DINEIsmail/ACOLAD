declare module "@salesforce/apex/AP_MoveAccount.newUpdateContact" {
  export default function newUpdateContact(param: {contactId: any, accountId: any, reason: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_MoveAccount.showPopin" {
  export default function showPopin(param: {contactId: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_MoveAccount.cancelMoveAccount" {
  export default function cancelMoveAccount(param: {contactId: any}): Promise<any>;
}
