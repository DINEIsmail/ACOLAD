declare module "@salesforce/apex/AP_NewEvaluation.getSourceValuesList" {
  export default function getSourceValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewEvaluation.getServicesValuesList" {
  export default function getServicesValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewEvaluation.getOwnersValuesList" {
  export default function getOwnersValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewEvaluation.getTargetValuesList" {
  export default function getTargetValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewEvaluation.getDomainSubDomainValuesList" {
  export default function getDomainSubDomainValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewEvaluation.getSavedValues" {
  export default function getSavedValues(param: {currentEvaluationId: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_NewEvaluation.getVendors" {
  export default function getVendors(param: {filtersJson: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_NewEvaluation.setModerator" {
  export default function setModerator(param: {evaluationId: any, selectedRow: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_NewEvaluation.addVendorsToEvaluation" {
  export default function addVendorsToEvaluation(param: {evaluationId: any, selectedRows: any}): Promise<any>;
}
