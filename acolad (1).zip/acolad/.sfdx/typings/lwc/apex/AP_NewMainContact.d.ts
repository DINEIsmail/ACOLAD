declare module "@salesforce/apex/AP_NewMainContact.getCommunicationLanguageValuesList" {
  export default function getCommunicationLanguageValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewMainContact.getSavedValues" {
  export default function getSavedValues(param: {currentMainContactId: any}): Promise<any>;
}
