declare module "@salesforce/apex/AP_NewProfile.getMotherTongueValuesList" {
  export default function getMotherTongueValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewProfile.getSavedValues" {
  export default function getSavedValues(param: {currentProfileId: any}): Promise<any>;
}
