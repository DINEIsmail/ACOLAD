declare module "@salesforce/apex/AP_NewRateProfile.getSourcesValuesList" {
  export default function getSourcesValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewRateProfile.getTargetsValuesList" {
  export default function getTargetsValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewRateProfile.getDomainsValuesList" {
  export default function getDomainsValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewRateProfile.getServicesValuesList" {
  export default function getServicesValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewRateProfile.getSavedValues" {
  export default function getSavedValues(param: {rateProfileId: any}): Promise<any>;
}
