declare module "@salesforce/apex/AP_NewVendor.getRecordtypeDeveloperName" {
  export default function getRecordtypeDeveloperName(param: {aRecordtypeId: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_NewVendor.getStatesValuesList" {
  export default function getStatesValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewVendor.getAssignedVMValuesList" {
  export default function getAssignedVMValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewVendor.getCountryValuesList" {
  export default function getCountryValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewVendor.getVerifiedByValuesList" {
  export default function getVerifiedByValuesList(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewVendor.getUserDetails" {
  export default function getUserDetails(): Promise<any>;
}
declare module "@salesforce/apex/AP_NewVendor.getSavedValues" {
  export default function getSavedValues(param: {currentVendorId: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_NewVendor.getCountryIso3Codes" {
  export default function getCountryIso3Codes(param: {aCountryName: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_NewVendor.getCityPicklistValues" {
  export default function getCityPicklistValues(param: {aLocation: any, iso3CountryCode: any}): Promise<any>;
}
declare module "@salesforce/apex/AP_NewVendor.getMotherTongueValuesList" {
  export default function getMotherTongueValuesList(): Promise<any>;
}
