declare module "@salesforce/apex/MasterCatGridManager.updateMasterCatGrid" {
  export default function updateMasterCatGrid(param: {accountId: any, catGridId: any, confirmed: any}): Promise<any>;
}
