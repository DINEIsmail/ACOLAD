declare module "@salesforce/apex/VendorSearchController.getVendorInformations" {
  export default function getVendorInformations(param: {VendorId: any}): Promise<any>;
}
declare module "@salesforce/apex/VendorSearchController.addPP" {
  export default function addPP(param: {vendorId: any, profile: any, sourcelanguage: any, destlanguage: any}): Promise<any>;
}
