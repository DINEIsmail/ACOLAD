declare module "@salesforce/apex/VendorService.retrieveContactData" {
  export default function retrieveContactData(param: {keySearchType: any, keySearchByCountry: any, profileAcoladCompany: any, profileselectedStatus: any, checkboxGTCapproved: any, checkboxVIPprofile: any, PMServices: any, PMLanguageSource: any, PMLanguageDest: any, PMstatus: any, PMRate: any}): Promise<any>;
}
