declare module "@salesforce/resourceUrl/sl_style" {
    var sl_style: string;
    export default sl_style;
}