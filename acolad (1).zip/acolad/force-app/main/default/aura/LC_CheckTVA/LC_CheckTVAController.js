({
	doInit : function(component, event, helper) {
		helper.doInit(component, event, helper);
	},
    
    yes : function(component, event, helper) {
		helper.yes(component, event, helper);
	},
    
    no : function(component, event, helper) {
		helper.no(component, event, helper);
	},
    
    ok : function(component, event, helper) {
		helper.ok(component, event, helper);
	}
})