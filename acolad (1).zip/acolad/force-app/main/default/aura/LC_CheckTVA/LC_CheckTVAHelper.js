({
    doInit : function(component, event, helper) {
        helper.initialisePlatformEvents(component, event, helper);
    },
    
    checkTVANumber : function(component, event, helper){
        var accountId = component.get('v.recordId');
        this.callServer(component,
                        "c.checkTVA",
                        function(response){
                            if(response){                                
                                component.set('v.countryCode', response.countryCode);
                                component.set('v.vatNumber', response.vatNumber);
                                component.set('v.valid', response.valid);
                                if(response.valid==false){
                                component.set('v.errorMessage', 'VAT number invalid, please enter a valid number on the account');      
                                component.set('v.updateVAT',false);                
                                }
                                component.set('v.name', response.name);
                                component.set('v.address', response.address);
                                component.set('v.responseReady', true);
                            }
                        },
                        {
                            accountId : accountId
                        })
    },
       
	initialisePlatformEvents : function(component, event, helper) {
		const empApi = component.find("empApi");
		empApi.setDebugFlag(false);
        const channel = component.get("v.eventChannel");
        const replayId = -1; 
        empApi.subscribe(channel, replayId, $A.getCallback(eventReceived => {
			//eventReceived.data.payload
			console.log("### platform event handled");
			const payload = eventReceived.data.payload;
            const accountId = component.get("v.recordId");
            if(accountId == payload.ObjectId__c){
            	helper.checkTVANumber(component, event, helper);
        	}
        }))
        .then(subscription => {
            console.log('Subscribed to channel ', subscription.channel);
            component.set('v.subscription', subscription);
		});
    },
    
    yes : function(component, event, helper) {
        var accountId = component.get('v.recordId');       
        this.callServer(component,
                        "c.updateAccountVTA_Yes",
                        function(response){
                            console.log(response)   ;   
                            if(response === 'KO'){    
                                component.set('v.updateVAT',true);               
                                component.set('v.errorMessage','We were not able to split this address correctly, so we put it all in the "Billing Street" field. Please split the information in the correct fields (or you won\'t be able to close your opportunities)');
                                component.set('v.valid', false);
                            }else{
                            component.set('v.responseReady', false);
                            $A.get('e.force:refreshView').fire();
                            }
                         
                            
                        },
                        {
                            accountId : accountId,
                            LegalName :  component.get('v.name'),
                            BillingAddress : component.get('v.address'),
                            tvaNumber : component.get('v.vatNumber'),
                            billingCountryCode : component.get('v.countryCode')
                        })
    },
    
    no : function(component, event, helper) {
        var accountId = component.get('v.recordId');        
        this.callServer(component,
                        "c.updateAccountVTA_No",
                        function(response){
                            component.set('v.responseReady', false);
                            $A.get('e.force:refreshView').fire();
                        },
                        {   updateVAT : true ,
                            accountId : accountId
                        })
    },
    
    ok : function(component, event, helper) {
        var accountId = component.get('v.recordId');        
        this.callServer(component,
                        "c.updateAccountVTA_No",
                        function(response){
                            component.set('v.responseReady', false);
                            $A.get('e.force:refreshView').fire();
                        },
                        {   updateVAT :  component.get('v.updateVAT'),
                            accountId : accountId
                        })	
    }
})