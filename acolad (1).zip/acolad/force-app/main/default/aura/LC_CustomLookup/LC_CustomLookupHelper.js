({
    doInit : function(component, event, helper) {
        helper.updateFields(component, event, helper);
        helper.multiPickListIsRequiredInitHandler(component, event, helper);
    },
    multiPickListIsRequiredInitHandler : function(component, event, helper){
        const multiPickListDisplayList = component.get("v.multiPickListDisplayList");
        const isMultiPickList = component.get("v.isMultiPickList");
        const isRequired = component.get("v.isRequired");
        if(isRequired && isMultiPickList){
            if(multiPickListDisplayList.length > 0){
                component.set("v.isRequiredMultiPickList", false);
            }
            else{
                component.set("v.isRequiredMultiPickList", true);
            }            
        }
    },
    updateFields : function(component, event, helper){
        var defaultValue = component.get("v.defaultValue");
        var recordId = component.get("v.recordId");
        if(recordId && recordId != "" 
           && defaultValue && defaultValue != ""){
            const isMultiPickList = component.get("v.isMultiPickList");
            if(isMultiPickList){
                helper.getMultiPickListValuesFromDefault(component, event, helper);
            }
            else{
                component.set("v.searchedKeyWord", defaultValue);
                component.set("v.showSearchResults", false);   
            }
        }
    },
    getMultiPickListValuesFromDefault : function(component, event, helper){
        let defaultValue = component.get("v.defaultValue");
        let apiValueList = defaultValue.split(";");
        const allValuesList = component.get("v.allValuesList");
        let multiPickListDisplayList = [];
        for(let i=0;i<apiValueList.length;i++){
            for(let j=0;j<allValuesList.length;j++){
                if(apiValueList[i] == allValuesList[j].apiValue){
                    multiPickListDisplayList.push(allValuesList[j]);
                }
            }
        }
        component.set("v.multiPickListDisplayList", multiPickListDisplayList);
    },
    defaultValuehandler : function(component, event, helper){
        var applyDefaultValue = component.get("v.applyDefaultValue");
        var allValuesList = component.get("v.allValuesList");
        var defaultValue = component.get("v.defaultValue");
        var searchedKeyWord = component.get("v.searchedKeyWord");
        if(applyDefaultValue 
           && allValuesList && allValuesList.length > 0 
           && defaultValue && defaultValue != ""){
            let found = false;
            for(var i=0;i<allValuesList.length;i++){
                if(defaultValue == allValuesList[i].label){
                    found = true;
                    component.set("v.searchedKeyWord", defaultValue);
                    break;
                }
            }
            if(!found){
                component.set("v.searchMatchedValuesList", allValuesList);
                component.set("v.showSearchResults", true);
            }
        }         
        else if((!searchedKeyWord || searchedKeyWord == "")
                && allValuesList && allValuesList.length > 0){
            component.set("v.searchMatchedValuesList", allValuesList);
            component.set("v.showSearchResults", true);
        }
        component.set("v.applyDefaultValue", false);
    },
    searchKeyPressController : function(component, event, helper){
        component.set("v.choiceMadeFromList", false);
        var searchedKeyWord = component.get("v.searchedKeyWord");
        var allValuesList = component.get("v.allValuesList");
        var isEmpty;
        if(searchedKeyWord 
           && searchedKeyWord != ""){
            isEmpty = false;
            var searchMatchedValuesList = [];
            if(allValuesList.length != 0){
                var searchedKeyWordUpperCase = searchedKeyWord.toUpperCase();
                var listValueUpperCase;
                for(var i=0;i<allValuesList.length;i++){
                    listValueUpperCase = allValuesList[i].label.toUpperCase();
                    if(listValueUpperCase.startsWith(searchedKeyWordUpperCase)){
                        searchMatchedValuesList.push(allValuesList[i]);
                    }
                }
                if(searchMatchedValuesList.length > 0){
                    component.set("v.showSearchResults", true);
                    component.set("v.searchMatchedValuesList", searchMatchedValuesList);
                    component.set("v.searchMessage", "");
                }
                else{
                    var searchMessage = "No result found";
                    component.set("v.searchMessage", searchMessage);
                    var emptyList = [];
                    component.set("v.searchMatchedValuesList", emptyList);
                }
            }
        }
        else{
            component.set("v.searchMatchedValuesList", allValuesList);
            component.set("v.searchedKeyWord", "");
            isEmpty = true;
        }        
        helper.notifyParentOfEmptyValues(component, event, helper, isEmpty);
    },
    notifyParentOfEmptyValues : function(component, event, helper, isEmpty){
        var searchedKeyWord = component.get("v.searchedKeyWord");
        var fieldDetails = {
            "fieldApiName" : component.get("v.fieldApiName"),
            "isEmpty" : isEmpty,
            "searchedKeyWord" : searchedKeyWord
        };
        var myEvent = component.getEvent("emptyInputNotification");
        myEvent.setParams({"fieldDetails" : fieldDetails });
        myEvent.fire();
    },
    handleSelectedValueEvent : function(component, event, helper){
        var selectedValue = event.getParams("arguments");
        if(selectedValue){
            const isMultiPickList = component.get("v.isMultiPickList");
            var objectApiName = component.get("v.objectApiName");
            var fieldApiName = component.get("v.fieldApiName");
            var chosenValue = {
                "label" : selectedValue.selectedValueDetails.label,
                "apiValue" : selectedValue.selectedValueDetails.apiValue,
            }
            component.set("v.selectedValue", chosenValue);
            if(objectApiName == selectedValue.selectedValueDetails.objectApiName 
               && fieldApiName == selectedValue.selectedValueDetails.fieldApiName){
                if(isMultiPickList){
                    helper.multiPickListHandler(component, event, helper);
                }
                else{                    
					helper.simplePickListValueHandler(component, event, helper);
                }
            }            
        }
    },
    simplePickListValueHandler : function(component, event, helper){
        const selectedValue = component.get("v.selectedValue");
        component.set("v.searchedKeyWord", selectedValue.label);
        component.set("v.showSearchResults", false);
        component.set("v.choiceMadeFromList", true);
        helper.sendSelectedValueToParent(component, event, helper);
    },
    multiPickListHandler : function(component, event, helper){
		helper.checkForDuplicatesAndAddToList(component, event, helper);
        component.set("v.searchedKeyWord", "");
        component.set("v.showSearchResults", false);
        component.set("v.choiceMadeFromList", true);
        helper.sendSelectedValueToParent(component, event, helper);
    },
    checkForDuplicatesAndAddToList : function(component, event, helper){
        let selectedValue = component.get("v.selectedValue");
        let multiPickListDisplayList = component.get("v.multiPickListDisplayList");
        if(selectedValue){
            if(multiPickListDisplayList.length == 0){
                multiPickListDisplayList.push(selectedValue);
            }
            else if(multiPickListDisplayList.length > 0){
                let found = false;
                for(let i=0;i<multiPickListDisplayList.length;i++){
                    if(multiPickListDisplayList[i].apiValue == selectedValue.apiValue){
                        found = true;
                    }
                }
                if(!found){
                    multiPickListDisplayList.push(selectedValue);
                }
			}
            component.set("v.multiPickListDisplayList", multiPickListDisplayList);
            helper.buildMultiPicklistSelectedValue(component, event, helper);
        }
    },
    buildMultiPicklistSelectedValue : function(component, event, helper){
        const multiPickListDisplayList = component.get("v.multiPickListDisplayList");   
        let selectedValue;
        if(multiPickListDisplayList.length  > 0){
            let selectedValueApiName = "";
            for(let i=0;i<multiPickListDisplayList.length;i++){
                if(selectedValueApiName == ""){
                    selectedValueApiName = multiPickListDisplayList[i].apiValue;
                }
                else{
                    selectedValueApiName = multiPickListDisplayList[i].apiValue + ";" + selectedValueApiName;
                }
            }
            selectedValue = {
                "label" : "",
                "apiValue" : selectedValueApiName,
            }            
        }
        else{
            selectedValue = {
                "label" : "",
                "apiValue" : "",
            }
        }
        component.set("v.selectedValue", selectedValue);
    },
    sendSelectedValueToParent : function(component, event, helper){
        var selectedValue = component.get("v.selectedValue");
        var objectApiName = component.get("v.objectApiName");
        var fieldApiName = component.get("v.fieldApiName");
        var selectedValueDetails = {
            "label" : selectedValue.label,
            "apiValue" : selectedValue.apiValue,
            "objectApiName" : objectApiName,
            "fieldApiName" : fieldApiName
        }
        var myEvent = component.getEvent("sendSelectedValue");
        myEvent.setParams({"selectedValueDetails" : selectedValueDetails });
        myEvent.fire();
        helper.refreshInputField(component, event, helper);
    },
    refreshInputField : function(component, event, helper){
        component.set("v.showInputField", false);
        component.set("v.showInputField", true);
    },
    onBlurhandler : function(component, event, helper){
        const searchedKeyWord = component.get("v.searchedKeyWord");
        if(searchedKeyWord && searchedKeyWord != ""){
            const choiceMadeFromList = component.get("v.choiceMadeFromList");
            const searchMatchedValuesList = component.get("v.searchMatchedValuesList");
            const upperCaseSearchedKeyWord = searchedKeyWord.toUpperCase();
            let upperCaseListValue;
            let found = false;
            for(let i=0;i<searchMatchedValuesList.length;i++){
                upperCaseListValue = searchMatchedValuesList[i].label.toUpperCase();
                if(upperCaseListValue.startsWith(upperCaseSearchedKeyWord)){
                    found = true;
                    break;
                }
            }
            if(!found){
                component.set("v.searchedKeyWord", "");
                component.set("v.showSearchResults", false);
            }
        }
    },
    handleValueToRemoveFromMultiPickList : function(component, event, helper){
        const selectedValue = event.getParams("arguments");
        if(selectedValue){
            const objectApiName = component.get("v.objectApiName");
            const fieldApiName = component.get("v.fieldApiName");
            if(objectApiName == selectedValue.selectedValueDetails.objectApiName 
               && fieldApiName == selectedValue.selectedValueDetails.fieldApiName){
                let multiPickListDisplayList = component.get("v.multiPickListDisplayList");
                let toRemoveApiName = selectedValue.selectedValueDetails.apiValue;
                for(let i=0;i<multiPickListDisplayList.length;i++){
                    if(multiPickListDisplayList[i].apiValue == toRemoveApiName){
                        multiPickListDisplayList.splice(i, 1);
                        break;
                    }
                }
                component.set("v.multiPickListDisplayList", multiPickListDisplayList);
                helper.buildMultiPicklistSelectedValue(component, event, helper);
                helper.sendSelectedValueToParent(component, event, helper);
            }
        }
    },
    multiPickListRequiredHandler : function(component, event, helper){
        const multiPickListDisplayList = component.get("v.multiPickListDisplayList");
        const isRequired = component.get("v.isRequired");
        if(isRequired){
            if(multiPickListDisplayList.length > 0){
                component.set("v.isRequiredMultiPickList", false);
            }
            else{
                component.set("v.isRequiredMultiPickList", true);
            }
        }
    },
    handleMultiPickListValueChange : function(component, event, helper){
        helper.multiPickListRequiredHandler(component, event, helper);
    }
})