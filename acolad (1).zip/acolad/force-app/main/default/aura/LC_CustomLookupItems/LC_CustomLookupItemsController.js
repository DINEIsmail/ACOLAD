({
	doInit : function(component, event, helper) {
		helper.doInit(component, event, helper);
	},
    selectValue : function(component, event, helper) {
		helper.selectValue(component, event, helper);
	}
})