({
    doInit : function(component, event, helper) {
        
    },
    selectValue : function(component, event, helper) {
        var searchResult = component.get("v.searchResult");
        var objectApiName = component.get("v.objectApiName");
        var fieldApiName = component.get("v.fieldApiName");
        var selectedValueDetails = {
            "label" : searchResult.label,
            "apiValue" : searchResult.apiValue,
            "objectApiName" : objectApiName,
            "fieldApiName" : fieldApiName
        }
        var myEvent = component.getEvent("selectedValue");
        myEvent.setParams({"selectedValueDetails" : selectedValueDetails });
        myEvent.fire();
	}
})