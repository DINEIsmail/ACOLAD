({
    doInit: function (component, event, helper) {
        helper.retriveSavedValues(component, event, helper);
    },
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },    
    closeAndCancelHandlers : function(component, event, helper){
        const recordId = component.get("v.recordId");
        let url = '/' + recordId;
        window.location.replace(url);        
    },
    handleCustomLookupValue : function (component, event, helper) {
        var selectedValue = event.getParams("arguments");
        if(selectedValue){
            var fieldApiName = selectedValue.selectedValueDetails.fieldApiName;
            if(fieldApiName == "Source__c"){
                component.set("v.selectedSources", selectedValue.selectedValueDetails.apiValue);
            }
            else if(fieldApiName == "Target__c"){
                component.set("v.selectedTargets", selectedValue.selectedValueDetails.apiValue);
            }
			else if(fieldApiName == "Domain_Sub_Domain__c"){
				component.set("v.selectedDomains", selectedValue.selectedValueDetails.apiValue);
			}
			else if(fieldApiName == "Services__c"){
				component.set("v.selectedServices", selectedValue.selectedValueDetails.apiValue);
            }
			else if(fieldApiName == "Owner__c"){
				component.set("v.selectedOwners", selectedValue.selectedValueDetails.apiValue);
            }
        }
    },
    handleEmptyValue : function (component, event, helper) {
        var emptyField = event.getParams("arguments");
        if(emptyField){
            if(emptyField.fieldDetails.fieldApiName == "Source__c" 
               && emptyField.fieldDetails.isEmpty){
                
            }
            else if(emptyField.fieldDetails.fieldApiName == "Target__c" 
                    && emptyField.fieldDetails.isEmpty){
                
            }
			else if(emptyField.fieldDetails.fieldApiName == "Domain_Sub_Domain__c" 
                    && emptyField.fieldDetails.isEmpty){
                
            }
			else if(emptyField.fieldDetails.fieldApiName == "Services__c" 
                    && emptyField.fieldDetails.isEmpty){
                
            }
			else if(emptyField.fieldDetails.fieldApiName == "Owner__c" 
                    && emptyField.fieldDetails.isEmpty){
                
            }
        }
    },
    retriveSavedValues : function(component, event, helper){
        this.callServer(component,
                        "c.getSavedValues",
                        function(response){
                            if(response 
                               && response.length > 0){
                                var evaluation = response[0];
                                if(evaluation.Source__c){
                                    component.set("v.selectedSources", evaluation.Source__c);
                                }
                                if(evaluation.Target__c){
                                    component.set("v.selectedTargets", evaluation.Target__c);
                                }
                                if(evaluation.Domain_Sub_Domain__c){
                                    component.set("v.selectedDomains", evaluation.Domain_Sub_Domain__c);
                                }
                                if(evaluation.Services__c){
                                    component.set("v.selectedServices", evaluation.Services__c);
                                }
                                if(evaluation.Owner__c){
                                    component.set("v.selectedOwners", evaluation.Owner__c);
                                }
                                helper.helperGetPicklistValues(component, event, helper);
                            }
                        },
                        {
                            "currentEvaluationId" : component.get("v.recordId")
                        })
    },
    helperGetPicklistValues : function(component, event, helper){
        console.log("BM helperGetPicklistValues inside");
        helper.getSourcesPickListValue(component, event, helper);
        helper.getTargetPickListValue(component, event, helper);
        helper.getDomainPickListValue(component, event, helper);
        helper.getServicesPickListValue(component, event, helper);
        helper.getOwnersPickListValue(component, event, helper)
    },
    getSourcesPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getSourceValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.sourcesPickListValuesList", response);
                                component.set("v.isSourcesValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    getTargetPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getTargetValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.targetsPickListValuesList", response);
                                component.set("v.isTargetsValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    getDomainPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getDomainSubDomainValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.domainsPickListValuesList", response);
                                component.set("v.isDomainsValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    getServicesPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getServicesValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.servicesPickListValuesList", response);
                                component.set("v.isServicesValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    getOwnersPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getOwnersValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.ownersPickListValuesList", response);
                                component.set("v.isOwnersValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    }
})