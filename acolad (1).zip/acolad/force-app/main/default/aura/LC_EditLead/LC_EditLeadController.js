({
    doInit : function(component, event, helper) {
        helper.doInit(component, event, helper);
    },
    
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },
    
    handleOnError : function(component, event, helper) {
        console.log('Inside : handleOnError');

        var errors = event.getParams();
        console.log(JSON.stringify(errors));  
       /* errors = errors.error.body.output.fieldErrors;
        console.log(JSON.stringify(errors));  
        
        var errorMsg='';
        for(var i=0; i < errors.length; i++){
            errorMsg += errors[i].message + '; ';
        }
        console.log('errorMsg : ' + errorMsg);
        component.find('OppMessage').setError(errorMsg);
        */
        
    },
    
    redirectToLead : function(component, event, helper) {
        var eUrl= $A.get("e.force:navigateToURL");
        eUrl.setParams({
            "url": '/' + component.get('v.recordId')
        });
        eUrl.fire();
    },
    
  /*  handleOnSuccess : function(component, event, helper) {
        var params = event.getParams(); //get event params
        var leadId = params.response.id; //get record id
        console.log('leadId  - ' + leadId); 
        
        var eUrl= $A.get("e.force:navigateToURL");
        eUrl.setParams({
            "url": '/' + leadId
        });
        eUrl.fire();
    },*/
})