({
     doInit : function(component, event, helper) {
         
        this.callServer(component,
                       "c.getLeadStatus",
                        function(response){
                            component.set('v.leadStatus', response)
                        },
                        {
                            leadId : component.get('v.recordId')
                        })
    },
})