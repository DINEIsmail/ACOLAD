({
	doInit : function(component, event, helper) {
		helper.doInit(component, event, helper);
	},
    valider : function(component, event, helper) {
        helper.valider(component, event, helper);
    }   
})