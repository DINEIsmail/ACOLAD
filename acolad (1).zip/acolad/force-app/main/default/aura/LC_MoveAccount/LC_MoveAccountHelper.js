({
    doInit : function(component, event, helper) {
		helper.initialisePlatformEvents(component, event, helper);
    },
    valider : function(component, event, helper) {
        var contactId = component.get('v.recordId');
        console.log('### contactId : ' + contactId);
        var reason = component.get('v.value');
        console.log('### reason : ' + reason); 
        this.callServer(component,
                        'c.updateContact',
                        function(response){
                            component.set("v.showModal", false);
                            window.location.replace('/' + contactId);
                        },
                        {
                            contactId : contactId,
                            reason : reason
                        })
    },
    showModalHandler : function(component, event, helper) {
        this.callServer(component,
                        'c.showPopin',
                        function(response){
                            console.log("### display modal : " + response);
                            component.set("v.showModal", response);
                        },
                        {
                            contactId : component.get("v.recordId")
                        })
    },
    initialisePlatformEvents : function(component, event, helper) {
		const empApi = component.find("empApi");
		empApi.setDebugFlag(false);
        const channel = component.get("v.eventChannel");
        const replayId = -1; 
        empApi.subscribe(channel, replayId, $A.getCallback(eventReceived => {
			//eventReceived.data.payload
			console.log("### platform event handled");
			const payload = eventReceived.data.payload;
            const contactId = component.get("v.recordId");
            if(contactId == payload.ObjectId__c){
            	helper.showModalHandler(component, event, helper);
        	}
        }))
        .then(subscription => {
            console.log('Subscribed to channel ', subscription.channel);
            component.set('v.subscription', subscription);
		});
    }
})