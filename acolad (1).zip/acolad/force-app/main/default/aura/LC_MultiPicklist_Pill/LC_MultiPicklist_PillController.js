({
	handleRemove : function(component, event, helper) {
		helper.handleRemove(component, event, helper);
	}
})