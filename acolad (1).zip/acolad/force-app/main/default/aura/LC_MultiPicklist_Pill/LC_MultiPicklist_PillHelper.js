({
	handleRemove : function(component, event, helper) {
		const selectedValue = component.get("v.selectedValue");
        const objectApiName = component.get("v.objectApiName");
        const fieldApiName = component.get("v.fieldApiName");
        let myEvent = component.getEvent("sendRemovedValues");
        let detailsToSend = {
            "label" : selectedValue.label,
            "apiValue" : selectedValue.apiValue,
            "objectApiName" : objectApiName,
            "fieldApiName" : fieldApiName
        }
        myEvent.setParams({"selectedValueDetails" : detailsToSend });
        myEvent.fire();
	}
})