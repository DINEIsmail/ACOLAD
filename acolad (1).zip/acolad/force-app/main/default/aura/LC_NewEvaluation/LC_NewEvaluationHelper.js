({
    doInit : function (component, event, helper) {
        console.log('## Inside doInit');
        helper.helperGetPicklistValues(component, event, helper);
    },
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },    
    closeAndCancelHandlers : function(component, event, helper){
        var url = '/lightning/o/Evaluation__c/list?filterName=Recent';
        console.log('url : ' + url);
        window.location.replace(url);
    },
    handleCustomLookupValue : function (component, event, helper) {
        var selectedValue = event.getParams("arguments");
        if(selectedValue){
            var fieldApiName = selectedValue.selectedValueDetails.fieldApiName;
            if(fieldApiName == "Source__c"){
                component.set("v.selectedSources", selectedValue.selectedValueDetails.apiValue);
            }
            else if(fieldApiName == "Target__c"){
                component.set("v.selectedTargets", selectedValue.selectedValueDetails.apiValue);
            }
			else if(fieldApiName == "Domain_Sub_Domain__c"){
				component.set("v.selectedDomains", selectedValue.selectedValueDetails.apiValue);
			}
			else if(fieldApiName == "Services__c"){
				component.set("v.selectedServices", selectedValue.selectedValueDetails.apiValue);
            }
			else if(fieldApiName == "Owner__c"){
				component.set("v.selectedOwners", selectedValue.selectedValueDetails.apiValue);
            }
        }
    },
    handleEmptyValue : function (component, event, helper) {
        var emptyField = event.getParams("arguments");
        if(emptyField){
            if(emptyField.fieldDetails.fieldApiName == "Source__c" 
               && emptyField.fieldDetails.isEmpty){
                
            }
            else if(emptyField.fieldDetails.fieldApiName == "Target__c" 
                    && emptyField.fieldDetails.isEmpty){
                
            }
			else if(emptyField.fieldDetails.fieldApiName == "Domain_Sub_Domain__c" 
                    && emptyField.fieldDetails.isEmpty){
                
            }
			else if(emptyField.fieldDetails.fieldApiName == "Services__c" 
                    && emptyField.fieldDetails.isEmpty){
                
            }
			else if(emptyField.fieldDetails.fieldApiName == "Owner__c" 
                    && emptyField.fieldDetails.isEmpty){
                
            }
        }
    },
    helperGetPicklistValues : function(component, event, helper){
        helper.getSourcesPickListValue(component, event, helper);
        helper.getTargetPickListValue(component, event, helper);
        helper.getDomainPickListValue(component, event, helper);
        helper.getServicesPickListValue(component, event, helper);
        helper.getOwnersPickListValue(component, event, helper)
    },
    getSourcesPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getSourceValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.sourcesPickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    getTargetPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getTargetValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.targetsPickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    getDomainPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getDomainSubDomainValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.domainsPickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    getServicesPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getServicesValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.servicesPickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    getOwnersPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getOwnersValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.ownersPickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    }
})