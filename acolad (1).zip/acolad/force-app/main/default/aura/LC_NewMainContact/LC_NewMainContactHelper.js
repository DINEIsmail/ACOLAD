({
    doInit : function(component, event, helper){
        helper.getVendorId(component, event, helper);
    },
    getVendorId : function(component, event, helper){
        let myApplicationEvent = $A.get("e.c:LC_VendorIdSearch_Application_Event");
        myApplicationEvent.fire();
    },
    handleVendorIdEvent : function(component, event, helper){
        let vendorId = event.getParam("vendorId");
        if(vendorId){
            var setVendorId = component.find("vendorField").set("v.value", vendorId);
        }
    },
    helperGetPicklistValues : function(component, event, helper){
        helper.getCommunicationLanguagePickListValue(component, event, helper);
    },
    getCommunicationLanguagePickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getCommunicationLanguageValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.communicationLanguagePickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },
    handleCustomLookupValue : function(component, event, helper){
        var selectedValue = event.getParams("arguments");
        if(selectedValue){
            var fieldApiName = selectedValue.selectedValueDetails.fieldApiName;
            if(fieldApiName == "Communication_Langage__c"){
				component.set("v.selectedCommunicationLanguage", selectedValue.selectedValueDetails.apiValue);
            }
        }
    },
    handleEmptyValue : function(component, event, helper){
        var emptyField = event.getParams("arguments");
        if(emptyField){
            if(emptyField.fieldDetails.fieldApiName == "Communication_Langage__c"){
                
            }
        }
    },
    getSelectedVendor : function(component, event, helper){
        const vendorField = component.find("vendorField");
        let vendorId = vendorField.get("v.value");
        return vendorId;
    },
    closeAndCancelHandlers : function(component, event, helper){
        const vendorId = helper.getSelectedVendor(component, event, helper);
        let url; 
        if(vendorId){
            url = '/' + vendorId;
        }
        else{
            url = '/lightning/o/Vendor__c/list?filterName=Recent';
        }
        window.location.replace(url);
    }
})