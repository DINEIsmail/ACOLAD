({
    doInit : function(component, event, helper){
        helper.doInit(component, event, helper);
    },    
    closeQuickAction : function(component, event, helper) {
       helper.closeAndCancelHandlers(component, event, helper);
    },    
    onSuccess : function(component, event, helper) {
        var record = event.getParam("response");
        var authorId = record.id; // 
        
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": "The record has been Saved successfully.",
            "type":"success"
        });
        toastEvent.fire();
		window.location.replace('/' + authorId);
    },   
    onSubmit : function(component, event, helper) {
        event.preventDefault();
        var fields = event.getParam("fields");
		let selectedCommunicationLanguage = component.get("v.selectedCommunicationLanguage");
        if(selectedCommunicationLanguage){
            //fields["Communication_Langage__c"] = selectedCommunicationLanguage;            
        }
        component.find("recordViewForm").submit(fields);
    },    
    onError : function(component, event, helper) {
        var error = event.getParams();
        var errorMessage = event.getParam("message");
        console.log("errorMessage");
        console.log(errorMessage);        
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": "Error : " + errorMessage,
            "type":"error"
        });
        toastEvent.fire();
    },
    spinnerShow : function (component, event, helper) {
        helper.spinnerShow(component, event, helper);
    },    
    spinnerHide : function (component, event, helper) {
        helper.spinnerHide(component, event, helper);
    },
    handleCustomLookupValue : function(component, event, helper){
        helper.handleCustomLookupValue(component, event, helper);
    },
    handleEmptyValue : function(component, event, helper){
        helper.handleEmptyValue(component, event, helper);
    }
})