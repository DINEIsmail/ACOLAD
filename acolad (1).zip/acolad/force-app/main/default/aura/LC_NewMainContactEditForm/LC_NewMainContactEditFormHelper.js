({
    doInit : function(component, event, helper){
       
    },
    retriveSavedValues : function(component, event, helper){
        this.callServer(component,
                        "c.getSavedValues",
                        function(response){
                            if(response 
                               && response.length > 0){
                                var vendor = response[0];
                                if(vendor.Communication_Langage__c){
                                    component.set("v.selectedCommunicationLanguage", vendor.Communication_Langage__c);
                                }                                
                                helper.helperGetPicklistValues(component, event, helper);
                            }
                        },
                        {
                            "currentMainContactId" : component.get("v.recordId")
                        })
    },
    helperGetPicklistValues : function(component, event, helper){
        helper.getCommunicationLanguagePickListValue(component, event, helper);
    },
    getCommunicationLanguagePickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getCommunicationLanguageValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.communicationLanguagePickListValuesList", response);
                                component.set("v.isCommunicationLanguageLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },
    handleCustomLookupValue : function(component, event, helper){
        var selectedValue = event.getParams("arguments");
        if(selectedValue){
            var fieldApiName = selectedValue.selectedValueDetails.fieldApiName;
            if(fieldApiName == "Communication_Langage__c"){
				component.set("v.selectedCommunicationLanguage", selectedValue.selectedValueDetails.apiValue);
            }
        }
    },
    handleEmptyValue : function(component, event, helper){
        var emptyField = event.getParams("arguments");
        if(emptyField){
            if(emptyField.fieldDetails.fieldApiName == "Communication_Langage__c"){
                
            }
        }
    },
    closeAndCancelHandlers : function(component, event, helper){
        const recordId = component.get("v.recordId");
    	let url = '/' + recordId;
        window.location.replace(url);
    }
})