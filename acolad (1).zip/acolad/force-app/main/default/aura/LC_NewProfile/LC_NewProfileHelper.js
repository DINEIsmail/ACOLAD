({
    doInit : function(component, event, helper){
        console.log("BM INIT !!");
        helper.getVendorId(component, event, helper);
        helper.helperGetPicklistValues(component, event, helper);
    },
    getVendorId : function(component, event, helper){
        let myApplicationEvent = $A.get("e.c:LC_VendorIdSearch_Application_Event");
        myApplicationEvent.fire();
    },
    handleVendorIdEvent : function(component, event, helper){
        let vendorId = event.getParam("vendorId");
        if(vendorId){
            var setVendorId = component.find("vendorField").set("v.value", vendorId);
        }
    },
    helperGetPicklistValues : function(component, event, helper){
        helper.getMotherTonguePickListValue(component, event, helper);
    },
    getMotherTonguePickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getMotherTongueValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.motherTonguePickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },
    handleCustomLookupValue : function(component, event, helper){
        var selectedValue = event.getParams("arguments");
        if(selectedValue){
            var fieldApiName = selectedValue.selectedValueDetails.fieldApiName;
            if(fieldApiName == "Mother_Tongue__c"){
				component.set("v.selectedMotherTongue", selectedValue.selectedValueDetails.apiValue);
            }
        }
    },
    handleEmptyValue : function(component, event, helper){
        var emptyField = event.getParams("arguments");
        if(emptyField){
            if(emptyField.fieldDetails.fieldApiName == "Mother_Tongue__c"){
                
            }
        }
    }
})