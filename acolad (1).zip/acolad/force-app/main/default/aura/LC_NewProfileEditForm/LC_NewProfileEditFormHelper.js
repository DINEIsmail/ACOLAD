({
    doInit : function(component, event, helper){
        helper.retriveSavedValues(component, event, helper);
    },
    retriveSavedValues : function(component, event, helper){
        this.callServer(component,
                        "c.getSavedValues",
                        function(response){
                            if(response 
                               && response.length > 0){
                                var vendor = response[0];
                                if(vendor.Mother_Tongue__c){
                                    component.set("v.selectedMotherTongue", vendor.Mother_Tongue__c);
                                }                                
                                helper.helperGetPicklistValues(component, event, helper);
                            }
                        },
                        {
                            "currentProfileId" : component.get("v.recordId")
                        })
    },
    helperGetPicklistValues : function(component, event, helper){
        helper.getMotherTonguePickListValue(component, event, helper);
    },
    getMotherTonguePickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getMotherTongueValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.motherTonguePickListValuesList", response);
                                component.set("v.isMotherTonguePickListValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },
    handleCustomLookupValue : function(component, event, helper){
        var selectedValue = event.getParams("arguments");
        if(selectedValue){
            var fieldApiName = selectedValue.selectedValueDetails.fieldApiName;
            if(fieldApiName == "Mother_Tongue__c"){
				component.set("v.selectedMotherTongue", selectedValue.selectedValueDetails.apiValue);
            }
        }
    },
    handleEmptyValue : function(component, event, helper){
        var emptyField = event.getParams("arguments");
        if(emptyField){
            if(emptyField.fieldDetails.fieldApiName == "Mother_Tongue__c"){
                
            }
        }
    }
})