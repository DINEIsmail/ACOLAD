({
    doInit : function(component, event, helper){
        helper.getVendorId(component, event, helper);
        helper.helperGetPicklistValues(component, event, helper);
    },
    getVendorId : function(component, event, helper){
        let myApplicationEvent = $A.get("e.c:LC_VendorIdSearch_Application_Event");
        myApplicationEvent.fire();
    },
    handleVendorIdEvent : function(component, event, helper){
        let vendorId = event.getParam("vendorId");
        if(vendorId){
            var setVendorId = component.find("vendorField").set("v.value", vendorId);
        }
    },
    helperGetPicklistValues : function(component, event, helper){
        helper.getSourcesPickListValue(component, event, helper);
        helper.getTargetPickListValue(component, event, helper);
        helper.getDomainPickListValue(component, event, helper);
        helper.getServicesPickListValue(component, event, helper);        
    },
    getSourcesPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getSourcesValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.sourcesPickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    getTargetPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getTargetsValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.targetsPickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    getDomainPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getDomainsValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.domainsPickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    getServicesPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getServicesValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.servicesPickListValuesList", response);
                            }
                        },
                        {
                            
                        })
    },
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },
    handleCustomLookupValue : function(component, event, helper){
        var selectedValue = event.getParams("arguments");
        if(selectedValue){
            var fieldApiName = selectedValue.selectedValueDetails.fieldApiName;
            if(fieldApiName == "Sources__c"){
				component.set("v.selectedSources", selectedValue.selectedValueDetails.apiValue);
            }
            else if(fieldApiName == "Targets__c"){
                component.set("v.selectedTargets", selectedValue.selectedValueDetails.apiValue);
            }
			else if(fieldApiName == "Domains__c"){
				component.set("v.selectedDomains", selectedValue.selectedValueDetails.apiValue);
			}
			else if(fieldApiName == "Services__c"){
				component.set("v.selectedServices", selectedValue.selectedValueDetails.apiValue);
			}
        }
    },
    handleEmptyValue : function(component, event, helper){
        var emptyField = event.getParams("arguments");
        if(emptyField){
            if(emptyField.fieldDetails.fieldApiName == "Sources__c"){
                
            }
            else if(emptyField.fieldDetails.fieldApiName == "Targets__c"){
                
            }
			else if(emptyField.fieldDetails.fieldApiName == "Domains__c"){
                
            }
			else if(emptyField.fieldDetails.fieldApiName == "Services__c"){
                
            }
        }
    },
    getSelectedVendor : function(component, event, helper){
        const vendorField = component.find("vendorField");
        let vendorId = vendorField.get("v.value");
        return vendorId;
    },
    closeAndCancelHandlers : function(component, event, helper){
        const vendorId = helper.getSelectedVendor(component, event, helper);
        let url;
        if(vendorId){
            url = '/' + vendorId;
        }
        else{
            url = '/lightning/o/Vendor__c/list?filterName=Recent';
        }        
        window.location.replace(url);
    }
})