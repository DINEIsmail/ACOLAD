({
    doInit : function(component, event, helper){
        helper.retriveSavedValues(component, event, helper);
    },
    retriveSavedValues : function(component, event, helper){
        this.callServer(component,
                        "c.getSavedValues",
                        function(response){
                            if(response 
                               && response.length > 0){
                                var vendor = response[0];
                                if(vendor.Country__c){
                                    component.set("v.selectedCountry", vendor.Country__c);
                                }                            
                                if(vendor.VerifiedBy__c){
                                    component.set("v.selectedVerifiedBy", vendor.VerifiedBy__c);
                                }
                                if(vendor.City__c){
                                    component.set("v.selectedCity", vendor.City__c);
                                }
                                if(vendor.States__c){
                                    component.set("v.selectedState", vendor.States__c);
                                }
                                if(vendor.Nationality__c){
                                    component.set("v.selectedNationality", vendor.Nationality__c);
                                }
                                if(vendor.Assigned_VM__c){
                                    component.set("v.selectedAssignedVM", vendor.Assigned_VM__c);
                                }
                                if(vendor.Mother_Tongue__c){
                                    component.set("v.selectedMotherTongue", vendor.Mother_Tongue__c);
                                }
                                if(vendor.RecordType){
                                    var setRecordTypeIdName = component.find("recordTypeField").set("v.value", vendor.RecordType.Id);
                                    component.set("v.recordtypeDeveloperName", vendor.RecordType.DeveloperName);
                                }
                                helper.helperGetPicklistValues(component, event, helper);
                            }
                        },
                        {
                            "currentVendorId" : component.get("v.recordId")
                        })
    },
    helperGetPicklistValues : function(component, event, helper){
        helper.getCountryPickListValue(component, event, helper);        
        helper.getVerifiedByPickListValue(component, event, helper);
        helper.getCityPicklistValues(component, event, helper);
        helper.getAssignedVMPickListValue(component, event, helper);
        helper.getStatesPickListValue(component, event, helper);
        helper.getMotherTonguePickListValue(component, event, helper);        
    },
    getMotherTonguePickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getMotherTongueValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.motherTonguePickListValuesList", response);
                                component.set("v.isMotherTonguePickListValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    getStatesPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getStatesValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.statePickListValuesList", response);
                                component.set("v.isStatePickListValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    getCountryPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getCountryValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.countryPickListValuesList", response);
                                component.set("v.isCountryPickListValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    getAssignedVMPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getAssignedVMValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.assignedVMPickListValuesList", response);
                                let checkResult = helper.retrieveUserDetails(component, event, helper, response);
                                if(checkResult.isPresent){
                                    component.set("v.selectedAssignedVM", checkResult.retrievedName);
                                }
                                component.set("v.isAssignedVMPickListValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    getVerifiedByPickListValue : function(component, event, helper){
        this.callServer(component,
                        "c.getVerifiedByValuesList",
                        function(response){
                            if(response 
                               && response.length > 0){
                                component.set("v.verifiedByPickListValuesList", response);
                                let checkResult = helper.retrieveUserDetails(component, event, helper, response);
                                if(checkResult.isPresent){
                                    component.set("v.selectedVerifiedBy", checkResult.retrievedName);
                                }
                                component.set("v.isVerifiedByPickListValuesLoaded", true);
                            }
                        },
                        {
                            
                        })
    },
    retrieveUserDetails : function(component, event, helper, listToVerify){
        let result = {
            "isPresent" : false,
            "retrievedName" : "no name"
        };
        this.callServer(component,
                        "c.getUserDetails",
                        function(response){
                            if(response 
                               && response.length > 0){
                                const retrievedName = response[0].Name;
                                let isPresent = helper.checkIfConnectedUserInVerifiedByPickList(component, event, helper, retrievedName, listToVerify);
                                if(isPresent){
                                    result.isPresent = true;
                                    result.retrievedName = retrievedName;
                                }                                
                            }
                        },
                        {
                            
                        })
        return result;
    },
    checkIfConnectedUserInVerifiedByPickList : function(component, event, helper, connectedUserName, listToVerify){
        let isPresent = false;
        const verifiedByPickListValuesList = listToVerify;
        if(verifiedByPickListValuesList.length > 0){
            for(let i=0;i<verifiedByPickListValuesList.length;i++){
                if(verifiedByPickListValuesList[i].apiValue == connectedUserName){
                    isPresent = true;
                    break;
                }
            }
        }
        return isPresent;
    },
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },
    handleCustomLookupValue : function(component, event, helper){
        var selectedValue = event.getParams("arguments");
        if(selectedValue){
            var fieldApiName = selectedValue.selectedValueDetails.fieldApiName;
            if(fieldApiName == "Country__c"){
				component.set("v.selectedCountry", selectedValue.selectedValueDetails.apiValue);
            }
            if(fieldApiName == "VerifiedBy__c"){
                component.set("v.selectedVerifiedBy", selectedValue.selectedValueDetails.apiValue);
            }
            if(fieldApiName == "City__c"){
                component.set("v.selectedCity", selectedValue.selectedValueDetails.apiValue);
            }
            if(fieldApiName == "States__c"){
                component.set("v.selectedState", selectedValue.selectedValueDetails.apiValue);
            }
            if(fieldApiName == "Nationality__c"){
                component.set("v.selectedNationality", selectedValue.selectedValueDetails.apiValue);
            }
            if(fieldApiName == "Assigned_VM__c"){
                component.set("v.selectedAssignedVM", selectedValue.selectedValueDetails.apiValue);
            }
            if(fieldApiName == "Mother_Tongue__c"){
                component.set("v.selectedMotherTongue", selectedValue.selectedValueDetails.apiValue);
            }            
        }
    },
    handleEmptyValue : function(component, event, helper){
        var emptyField = event.getParams("arguments");
        if(emptyField){
            if(emptyField.fieldDetails.fieldApiName == "Country__c"){
                if(emptyField.fieldDetails.isEmpty){
                    component.set("v.isCityChoiceDisabled", true);
                }
                else{
                    component.set("v.isCityChoiceDisabled", false);
                }
            }
            if(emptyField.fieldDetails.fieldApiName == "City__c"){
                if(!emptyField.fieldDetails.isEmpty){
                    var searchedKeyWord = emptyField.fieldDetails.searchedKeyWord;
                    component.set("v.selectedCity", searchedKeyWord);
                    helper.getCityPicklistValues(component, event, helper);
                }
                else{
                    var emptyList = [];
                    component.set("v.cityPickListValuesList", emptyList);
                }
            }
            if(emptyField.fieldDetails.fieldApiName == "VerifiedBy__c" 
               && emptyField.fieldDetails.isEmpty){
                component.set("v.selectedVerifiedBy", "");
            }
            if(emptyField.fieldDetails.fieldApiName == "States__c" 
               && emptyField.fieldDetails.isEmpty){
                component.set("v.selectedState", "");
            }
            if(emptyField.fieldDetails.fieldApiName == "Nationality__c" 
               && emptyField.fieldDetails.isEmpty){
                component.set("v.selectedNationality", "");
            }
            if(emptyField.fieldDetails.fieldApiName == "Assigned_VM__c" 
               && emptyField.fieldDetails.isEmpty){
                component.set("v.selectedAssignedVM", "");
            }
            if(emptyField.fieldDetails.fieldApiName == "Mother_Tongue__c" 
               && emptyField.fieldDetails.isEmpty){
                component.set("v.selectedMotherTongue", "");
            }
        }
    },
    handleChangeInCountry : function(component, event, helper){
        var selectedCountry = component.get("v.selectedCountry");
        if(selectedCountry && selectedCountry != ""){
            component.set("v.isCityChoiceDisabled", false);
            component.set("v.selectedCity", "");
            helper.retrieveCountryIsoCodes(component, event, helper);
        }
        else{
            component.set("v.isCityChoiceDisabled", true);
        }
    },
    getCityPicklistValues : function(component, event, helper){        
		var iso3CountryCode = component.get("v.iso3CountryCode");
        var selectedCity = component.get("v.selectedCity");
        if(selectedCity && selectedCity != ""){
            this.callServer(component,
                            "c.getCityPicklistValues",
                            function(response){
                                if(response 
                                   && response.length > 0){
                                    component.set("v.cityPickListValuesList", response);
                                }                                
                            },
                            {
                                "aLocation" : selectedCity,
                                "iso3CountryCode" : iso3CountryCode
                            })
        }
        component.set("v.isCityPickListValuesLoaded", true);
    },
    retrieveCountryIsoCodes : function(component, event, helper){
        var selectedCountry = component.get("v.selectedCountry");
        if(selectedCountry && selectedCountry != ""){
            this.callServer(component,
                            "c.getCountryIso3Codes",
                            function(response){
                                if(response){
                                    if(response){
                                        if(response == "USA"){
                                            component.set("v.showState", true);
                                        }
                                        else{
                                            component.set("v.showState", false);
                                        }
                                        component.set("v.iso3CountryCode", response);
                                    }                                    
                                }
                            },
                            {
                                "aCountryName" : selectedCountry
                            })
        }
    }
})