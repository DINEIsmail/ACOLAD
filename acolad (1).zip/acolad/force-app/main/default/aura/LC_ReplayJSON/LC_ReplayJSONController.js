({
	 doInit : function(component, event, helper) {
        helper.doInit(component, event, helper);
    },
    
     spinnerShow : function (component, event, helper) {
        helper.spinnerShow(component, event, helper);
    },
    
    spinnerHide : function (component, event, helper) {
        helper.spinnerHide(component, event, helper);
    }
})