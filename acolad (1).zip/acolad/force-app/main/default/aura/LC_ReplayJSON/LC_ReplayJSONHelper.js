({
    doInit : function(component, event, helper) {
        console.log('Inside Init');
        this.callServer(component,
                        'c.replayLog',
                        function(response){
                            console.log('### response : ' + response);
                            
                            var toastEvent = $A.get("e.force:showToast");
                            if(response.split('__')[0] === 'KO'){
                                toastEvent.setParams({
                                    "title": "Erreur!",
                                    "type":"error",
                                    "message": response.split('__')[1],
                                    "mode":"sticky"
                                });
                            }else if(response.split('__')[0] === 'OK'){
                                toastEvent.setParams({
                                    "title": "Succés!",
                                    "type":"success",
                                    "message": response.split('__')[1],
                                    "mode":"sticky"
                                });
                            }else{
                                toastEvent.setParams({
                                    "title": "Erreur!",
                                    "type":"error",
                                    "message": response
                                });
                            }
                            toastEvent.fire();
                            $A.get("e.force:closeQuickAction").fire(); 
                            $A.get('e.force:refreshView').fire();
                        },
                        {
                            logId : component.get('v.recordId')
                        })
        
    },
    
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    }
})