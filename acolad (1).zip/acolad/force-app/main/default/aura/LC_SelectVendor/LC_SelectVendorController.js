({
    doInit :  function(component, event, helper){
        try{
            helper.doInit(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },    
    closeQuickAction : function(component, event, helper) {
        try{
            helper.closeAndCancelHandlers(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },
    onSuccess : function(component, event, helper) {
        try{
            helper.onSuccess(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },
    onSubmit : function(component, event, helper) {
        try{
            helper.onSubmit(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },
    
    onError : function(component, event, helper) {
        try{
            console.log('### onError');
            helper.onError(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },
    
    handleRowAction : function(component, event, helper) {
        try{
            helper.handleRowAction(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },
    
    selectModerator : function(component, event, helper) {
        try{
            helper.selectModerator(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },
    
    addVendors : function(component, event, helper) {
        try{
            helper.addVendors(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },
    
    spinnerShow : function (component, event, helper) {
        try{
            helper.spinnerShow(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },    
    spinnerHide : function (component, event, helper) {
        try{
            helper.spinnerHide(component, event, helper);
        } catch (error) {
            console.error(error);
        }
    },
    
})