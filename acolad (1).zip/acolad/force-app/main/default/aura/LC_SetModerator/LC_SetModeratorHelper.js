({
    doInit : function (component, event, helper) {
        console.log('## Inside doInit');
        var userId = $A.get("$SObjectType.CurrentUser.Id");
        console.log(userId);
        component.set('v.userId', userId);
        
        component.set('v.columns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Email', fieldName: 'MainContact_Email__c', type: 'text'},
            {label: 'Mother Tongue', fieldName: 'Mother_Tongue__c', type: 'text'},
            {label: 'Main Activity', fieldName: 'Main_Activity__c', type: 'text'},
            {label: 'Country', fieldName: 'Country__c', type: 'text'}        
        ]);
        
        if(component.get('v.setModerator') == true){
            component.set('v.maxRowSelection',1);
        }
    },
    
    onSubmit : function(component, event, helper) {
        var fields = event.getParam("fields");
        console.log('### onSubmit with field ' + JSON.stringify(fields));
        this.callServer(component,
                        "c.getVendors",
                        function(response){
                            console.log(response);
                            component.set('v.vendors', response);
                        },
                        {
                            filtersJson : JSON.stringify(fields)
                        })
        
    },
    
    
    handleRowAction : function(component, event, helper) {
        var rows = event.getParam('selectedRows');
        console.log(rows);
        component.set('v.selectedVendors', rows);
    },
    
    addVendors : function(component, event, helper) {
        console.log('## Inside addVendors');
        var selectedRows = component.get('v.selectedVendors');
        console.log('## selectedRows ' + JSON.stringify(selectedRows));
        
        this.callServer(component,
                        "c.addVendorsToEvaluation",
                        function(response){
                            var message = response.split('_')[0] + " Vendor Evaluations created successfully.";
                            if(response.split('_')[1] > 0){
                                message += ' Remaining ' + response.split('_')[1]+ ' already exist.';
                            }
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "title": "Success!",
                                "type":"success",
                                "message": message
                            });
                            toastEvent.fire();
                        },
                        {
                            evaluationId : component.get('v.recordId'),
                            selectedRows : JSON.stringify(selectedRows)
                        })
    },
    
    selectModerator : function(component, event, helper) {
        console.log('## Inside selectModerator');
        var selectedRow = component.get('v.selectedVendors');
        console.log('## selected Moderator ' + JSON.stringify(selectedRow));
        
        this.callServer(component,
                        "c.setModerator",
                        function(response){
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "title": "Success!",
                                "type":"success",
                                "message": "Moderator set!"
                            });
                            toastEvent.fire();
                            $A.get("e.force:closeQuickAction").fire();
                            $A.get('e.force:refreshView').fire();
                        },
                        {
                            evaluationId : component.get('v.recordId'),
                            selectedRow : JSON.stringify(selectedRow)
                        });
        

    },
    
    spinnerShow : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.removeClass(m, "slds-hide");
    },
    spinnerHide : function (component, event, helper) {
        var m = component.find('modalspinner');
        $A.util.addClass(m, "slds-hide");
    },    
    closeAndCancelHandlers : function(component, event, helper){
        $A.get("e.force:closeQuickAction").fire();
    },
})