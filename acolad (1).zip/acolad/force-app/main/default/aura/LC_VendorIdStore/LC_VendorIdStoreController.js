({
	doInit : function(component, event, helper) {
		helper.doInit(component, event, helper);
	},
    handleVendorIdSearch : function(component, event, helper){
        helper.handleVendorIdSearch(component, event, helper);
    }
})