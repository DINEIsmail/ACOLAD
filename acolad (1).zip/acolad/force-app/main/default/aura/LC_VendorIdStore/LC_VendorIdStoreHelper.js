({
	doInit : function(component, event, helper) {
		
	},
    handleVendorIdSearch : function(component, event, helper){
        let appEvent = $A.get("e.c:LC_VendorId_Application_Event");
        appEvent.setParams({
            "vendorId" : component.get("v.recordId")
        });
        appEvent.fire();
    }
})