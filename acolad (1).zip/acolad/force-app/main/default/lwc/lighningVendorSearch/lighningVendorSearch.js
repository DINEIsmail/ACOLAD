import { LightningElement,api } from 'lwc';
import getVendorInformations from '@salesforce/apex/VendorSearchController.getVendorInformations';
import addPP from '@salesforce/apex/VendorSearchController.addPP';
export default class LighningVendorSearch extends LightningElement {
@api recordId;
@api VendorName;
@api LocalTMS;
@api RelatedAcoladCompany;
@api PriceParameters=[];
@api Profiles=[];
@api tableData=[];
@api columnFields=[];
@api renderAddLanguage ;
@api renderAddLanguage1 ;
@api renderAddLanguage2 ;
@api sourceLangage ;
@api destlanguage ; 
@api number =0 ;



async connectedCallback() {
    try{
    console.log('test');
    console.log(this.recordId);
   
    getVendorInformations({ VendorId:  this.recordId})
            .then(result => {
                console.log('ok');
                console.log(result);
                var resultjson=JSON.parse(result);
                console.log(resultjson.VendorName);
                this.VendorName=resultjson.VendorName;
                this.LocalTMS=resultjson.LocalTMS;
                this.RelatedAcoladCompany=resultjson.RelatedAcoladCompany;

                this.Profiles=resultjson.VendorProfiles;
                console.log(this.Profiles.length);
                this.tableData=[];
                for(var j=0;j<this.Profiles.length;j++)
                {
                    
                    
                    for(var i=0;i<this.Profiles[j].PriceParameters.length;i++)
                    {
                        this.PriceParameters.push(this.Profiles[j].PriceParameters[i]);
                        this.tableData.push(
                            { "LocalTMS": this.Profiles[j].LocalTMS, 
                                "RelatedAcoladCompany": this.Profiles[j].RelatedAcoladCompany,
                                "SourceLanguage":this.Profiles[j].PriceParameters[i].PriceParameterSourceLanguage, 
                                "TargetLanguage":this.Profiles[j].PriceParameters[i].PriceParameterTargetLanguage, 
                                "Service":this.Profiles[j].PriceParameters[i].PriceParameterService,
                                "MainDomain" :this.Profiles[j].PriceParameters[i].PriceParameterDomain,
                                "SubDomains" :this.Profiles[j].PriceParameters[i].PriceParameterSubDomain,
                                "Id":this.Profiles[j].PriceParameters[i].Id,
                                "Status":this.Profiles[j].PriceParameters[i].PriceParameterStatus,
                                "Rate":this.Profiles[j].PriceParameters[i].PriceParameterRate
                            });
                    }
                }
                this.columnFields=[
                    { label: 'Record Id', fieldName: 'Id' },
                    { label: 'Related Acolad Company', fieldName: 'RelatedAcoladCompany' },
                    { label: 'Local TMS', fieldName: 'LocalTMS' },
                    { label: 'Source Language', fieldName: 'SourceLanguage' },
                    { label: 'Target Language', fieldName: 'TargetLanguage'},
                    { label: 'Service', fieldName: 'Service' },
                    { label: 'Rate', fieldName: 'Rate__c' , editable: true},
                    { label: 'Status', fieldName: 'Status' , editable: true},
                    { label: 'Main Domain', fieldName: 'MainDomain' },
                    { label: 'Sub Domains', fieldName: 'SubDomains' }
                    
                ];
                console.log(this.tabledata);
                console.log(this.columnFields);
                console.log(this.PriceParameters);
            }).catch(error => {console.log('error');
                console.log(error);
                console.log('getReturnResults error is: ' + JSON.stringify(error));
                if (error.body) {
                    console.log('Apex Action error: ' + error.body.message);
                   
                }
                
            });
        }catch(error)
        {
            console.log(error);
        }
        }

        //(String vendorId , String profile,String sourcelanguage ,String destlanguage
        addPP(){
           console.log('entré ici'+this.Profiles[0].Id);
           addPP({ vendorId:  this.recordId , profile : this.Profiles[0].Id ,sourcelanguage : this.sourceLangage ,  destlanguage : this.destlanguage }).
           then(result => {
               if(result == 'OK'){
                console.log('entré ici connectedCallback');
              this.connectedCallback({ VendorId:  this.recordId}) ;
              this.renderAddLanguage = false  ;
              this.renderAddLanguage1 = false  ;
              this.renderAddLanguage2 = false  ;
              this.number = 0 ;
               }
           });
           
        }


        handleAccountSearch(){ 
           
            if(this.number==0){    
       this.renderAddLanguage = true ;
      
            }else if(this.number == 1){
                this.renderAddLanguage1 = true ;
            }else if(this.number == 2){
                this.renderAddLanguage2 = true ;
            }
            this.number ++ ;
          
        }



        get PMLanguage(){
            return [
                { label: 'All', value: 'All' },
                { label: 'Afar', value: 'Afar' },
                { label: 'Abkhazian', value: 'Abkhazian' },
                { label: 'Afrikaans (South Africa)', value: 'Afrikaans (South Africa)' },
                { label: 'Akan', value: 'Akan' },
                { label: 'Amharic', value: 'Amharic' },
                { label: 'Arabic (Saudi Arabia)', value: 'Arabic (Saudi Arabia)' },
                { label: 'Arabic (Lebanon)', value: 'Arabic (Lebanon)' },
                { label: 'Arabic (Egypt)', value: 'Arabic (Egypt)' },
                { label: 'Arabic (Algeria)', value: 'Arabic (Algeria)' },
                { label: 'Arabic (Bahrain)', value: 'Arabic (Bahrain)' },
                { label: 'French (France)', value: 'French (France)' },
                { label: 'French (Belgium)', value: 'French (Belgium)' },
            ];
    
        }


        HandleSourceLanguage(event){
            this.sourceLangage = event.detail.value;   
    
        }

        HandleDesLanguage(event){
           this.destlanguage =  event.detail.value;   
        }

    }