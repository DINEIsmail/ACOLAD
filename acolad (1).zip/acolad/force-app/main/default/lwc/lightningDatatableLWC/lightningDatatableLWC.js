import { LightningElement ,api,track} from 'lwc';

export default class LightningDatatableLWCExample extends LightningElement {
    @api tableData = [];
    @api columnFields=[];
    @api selectedRecords=[];
    @ api T;
    async connectedCallback() {
        try{
            console.log(this.T);
            console.log(this.tableData);
            console.log(this.columnFields);
            this.columnFields=[
                { label: 'Record Id', fieldName: 'Id' },
                { label: 'Price Parameter Number', fieldName: 'Name' },
                { label: 'Acolad company', fieldName: 'Acolad_company__c' },
                { label: 'Domains', fieldName: 'Domains__c'},
                { label: 'Sub-domains', fieldName: 'Sub_domains__c' }
            ];
            console.log(this.tableData);
            console.log(this.columnFields);
        }catch(ex)
        {
            console.log(ex);
        }
    }
    updateSelectedText(event) {
        try{
            var selectedRows = event.detail.selectedRows;
            
            for(var i=0;i<selectedRows.length;i++)
            {
                console.log(selectedRows[i].Id);
                this.selectedRecords.push(selectedRows[i]);
            }
        }catch(ex)
        {
            console.log(ex);
        }
    }
    
}