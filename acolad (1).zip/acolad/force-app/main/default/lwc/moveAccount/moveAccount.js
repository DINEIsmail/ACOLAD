import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import callMoveAccount from '@salesforce/apex/AP_MoveAccount.newUpdateContact'

export default class MoveAccount extends NavigationMixin(LightningElement) {
    @api recordId;
    value = '';
    showFooter =false;
    showSubmit =false ;
    selectedAccount ;
    moveReason ;
    progress = 0 ;
    isProgressing = false;
    get showSubmit(){
        return this.showSubmit;
    }
    get showDiv(){
        return this.showFooter ;
    }

 
    showToast(variant,message) {
        const event = new ShowToastEvent({
            title: 'Move Account',
            message: message,
            variant : variant,
        });
        this.dispatchEvent(event);
    }


    handleSuccess(event) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success',
                message: event.detail.apiName + ' created.',
                variant: 'success',
            }),
        );
    }
    handleChange(event) {
        console.log("You selected an account: " + event.detail.value[0]); 
        this.selectedAccount = event.detail.value[0] ;
  
    }

    handleOnChange(evt){
        const selectedValue = evt.detail.value;
        if(selectedValue === 'Mistake/Specification' || selectedValue === 'Company Evolution'){
           this.showSubmit =true ;
        }else{
            this.showSubmit =false ;
        }
        this.moveReason = selectedValue ;
        console.log('selected value '+selectedValue);

    }
    handleAction() {
     if(this.showFooter == true){
         this.showFooter = false ;
         this.showSubmit =false ;
     }else {
         this.showFooter =true ;
     }
    }


    get options() {
        return [
            { label: 'Contact was created on wrong account, or a more detailed account has been created for this contact', value: 'Mistake/Specification' },
            { label: 'Contact is evolving in the company (promotion, transfer)', value: 'Company Evolution' },
        ];
    }

  
    handleClick(){

        if(!this.selectedAccount){
            this.showToast('error','Please select an account !');
            return ;
        }
        this.toggleProgress();
        console.log("You selected an account: " + this.selectedAccount);
        console.log("ContactId " + this.recordId);
        this.showSubmit = false ;

        callMoveAccount( { contactId: this.recordId ,accountId : this.selectedAccount , reason : this.moveReason  } ).then(result => {

            console.log('result'+result);
          if(result == 'OK' ) {
            this.progress = 100 ;
            console.log('result is OK !');

            this.showToast('info','Your contact has been moved successfully, please refresh this page!');
            //this.navigateToRecordPage() ;
          }
        })
        .catch(error => {
          this.showSubmit = true ;
          this.toggleProgress();
          console.log("got error callFactureDoc ", name , error);
          if(error.body.pageErrors && error.body.pageErrors[0].message ){
            error =  error.body.pageErrors[0].message ;
          }else if (error.body.message){
            error =  error.body.message ;
          }
        
          this.showToast('error','Error occured when move account '+error);
        });
        
    }

  
    navigateToRecordPage() {
     
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: 'Contact',
                actionName: 'view'
            }
        });

    }

   

    toggleProgress() {
        if (this.isProgressing) {
            // stop
            this.progress  = 0 ;
            this.isProgressing = false;
            clearInterval(this._interval);
        } else {
            // start
            this.isProgressing = true;
            // eslint-disable-next-line @lwc/lwc/no-async-operation
            this._interval = setInterval(() => {
                this.progress = this.progress > 60 ? this.progress : this.progress + 7;
            }, 200);
        }
    }

}