import retrieveContactData from '@salesforce/apex/VendorService.retrieveContactData';
import { LightningElement, api, wire } from 'lwc';

export default class searchVendorComponent extends LightningElement {
 
    
 
    @api  profileAcoladCompany ;
    @api profileselectedStatus;
    @api checkboxGTCapproved ;
    @api checkboxVIPprofile ;
    
    


   @api currentAccountName;
   @api searchAccountName;
   @api searchByCountry;
   @api searchtype;
   @api currentType ;
   @api changeCountry ;

   @api PMServices ;
   @api PMLanguageSource ;
   @api PMLanguageDest;
   @api PMstatus;
   @api PMRate ;

   @api records;
   @api notFound;


    
   defaultSortDirection = 'asc';
   sortDirection = 'asc';
   sortedBy;


   HandlecheckboxGTCapproved(e) {
    this.checkboxGTCapproved = e.target.checked;
}

HandlecheckboxVIPprofile(e) {
    this.checkboxVIPprofile = e.target.checked;    
}
HandleprofileselectedStatus(event){
    this.profileselectedStatus = event.detail.value;   

}

HandleprofileAcoladCompany(event){
    this.profileAcoladCompany = event.detail.value;   

}


   handleChangeCountry(event){
       console.log(event);
    this.changeCountry = event.detail.value;   

   }

    handleChangeAccName(event){
      this.currentAccountName = event.target.value;      
    }
    HandlePMServices(event){
        this.PMServices = event.detail.value;   
    }

    HandleSourceLanguage(event){
        this.PMLanguageSource = event.detail.value;   

    }

    handlePMstatus(event){
        this.PMstatus = event.detail.value;   
    }

    handlePMRate(event){
        this.PMRate = event.target.value;   

    }
    HandleDesLanguage(event){
        this.PMLanguageDest = event.detail.value;   
    }
    get options() {
        return [
            { label: 'All', value: 'All' },
            { label: 'Freelance', value: 'Freelance' },
            { label: 'Agency', value: 'Agency' },
        ];
    }
    


    @api  columns = [
        { label: 'Vendor Name', fieldName: 'Name',sortable: true },
        {
            label: 'Type',
            fieldName: 'Type',
            sortable: true,
            cellAttributes: { alignment: 'left' }
        },
        { label: 'Country', fieldName: 'BillingCountry',sortable: true  },
    ];

        
      


    get profileAcoladCompanyOptions(){
        return [
            { label: 'All', value: 'All' },
            { label: 'AAC Global', value: 'AA' },
            { label: 'Acolad', value: 'Acolad' },
            { label: 'Arancho Doc', value: 'AI' },
            { label: 'Arancho Doc Nordic', value: '	AN' },
            { label: 'Arancho Doc Spain', value: 'AS' },
            { label: 'Arancho Doc Switzerland', value: 'AH' },
            { label: 'Cogen', value: 'CG' },
            { label: 'HL TRAD BENELUX', value: 'CP' },
            { label: 'HL TRAD FRANCE', value: '	HL' },
            { label: 'HL TRAD GERMANY', value: 'HG' },
            { label: 'HL TRAD SUISSE', value: 'HS' },
            { label: 'HL TRAD UK', value: '	HU' },
            { label: 'Livewords', value: 'Livewords' },
            { label: 'Livewords Interpreting', value: '	Livewords Interpreting' },
            { label: 'Livewords Translation -', value: 'Livewords Translation -' },
            { label: 'Arancho Doc Spain', value: 'Blocked' },
            { label: 'Semantis', value: 'SE' },
            { label: 'Technicis Finance', value: 'FI' },
            { label: 'Technicis SAS', value: 'TE' },
            { label: 'Technicis technology', value: 'TT' },
            { label: 'TELELINGUA BELGIUM', value: '	TI' },
            { label: 'TELELINGUA FRANCE', value: '	TF' },
            { label: 'Telelingua Project Solutions', value: 'TP' },
            { label: 'TELELINGUA USA', value: 'TU' },
            { label: 'Translation Probst', value: 'Translation Probst' },
            { label: 'VO Paris', value: 'VO' },

        ];
    }

    get PMServicesVal(){
        return [
            { label: 'All', value: 'All' },
            { label: 'Translation services', value: 'Translation services' },
            { label: 'Learning services', value: 'Learning services' },
            { label: 'Content creation', value: 'Content creation' },
            { label: 'Multimedia Services', value: 'Multimedia Services' },
            { label: 'Webservices', value: 'Webservices' },
            { label: 'DTP', value: 'DTP' },
            { label: 'SEO', value: 'SEO' },
            { label: 'Project Solutions', value: 'Project Solutions' },
            { label: 'MT / Post Editing', value: 'MT / Post Editing' },
            { label: 'Interpreting', value: 'Interpreting' },
            { label: 'Products', value: 'Products' },
            { label: 'Revision', value: 'Revision' },
        ];

    }


    get PMLanguage(){
        return [
            { label: 'All', value: 'All' },
            { label: 'Afar', value: 'Afar' },
            { label: 'Abkhazian', value: 'Abkhazian' },
            { label: 'Afrikaans (South Africa)', value: 'Afrikaans (South Africa)' },
            { label: 'Akan', value: 'Akan' },
            { label: 'Amharic', value: 'Amharic' },
            { label: 'Arabic (Saudi Arabia)', value: 'Arabic (Saudi Arabia)' },
            { label: 'Arabic (Lebanon)', value: 'Arabic (Lebanon)' },
            { label: 'Arabic (Egypt)', value: 'Arabic (Egypt)' },
            { label: 'Arabic (Algeria)', value: 'Arabic (Algeria)' },
            { label: 'Arabic (Bahrain)', value: 'Arabic (Bahrain)' },
            { label: 'French (France)', value: 'French (France)' },
            { label: 'French (Belgium)', value: 'French (Belgium)' },
        ];

    }


    get profileStatusoptions(){
        return [
            { label: 'None', value: 'None' },
            { label: 'Applied', value: 'Applied' },
            { label: 'Approved', value: 'Approved' },
            { label: 'Rejected', value: 'Rejected' },
            { label: 'Blocked', value: 'Blocked' },
        ];
    }

    get Countryoptions(){
        return [
            { label: 'France', value: 'France' },
            { label: 'Andorra', value: 'Andorra' },
            { label: 'Algeria', value: 'Algeria' },
            { label: '--None--', value: 'None' },
        ];
    }
    handleAccountSearch(){
      //  this.searchAccountName = this.currentAccountName;
        this.searchtype  = this.currentType ;
        this.searchByCountry = this.changeCountry ;
       console.log( 'test PM '+ this.PMServices +this.PMLanguageSource+this.PMLanguageSource  +this.PMLanguageDest + this.PMstatus + this.PMRate  ) ;

        retrieveContactData( {  keySearchType : this.searchtype, keySearchByCountry : this.changeCountry , profileAcoladCompany : this.profileAcoladCompany ,
            profileselectedStatus : this.profileselectedStatus,checkboxGTCapproved : this.checkboxGTCapproved , checkboxVIPprofile : this.checkboxVIPprofile,
            PMServices :this.PMServices, PMLanguageSource : this.PMLanguageSource,PMLanguageDest: this.PMLanguageDest , PMstatus : this.PMstatus , PMRate : this.PMRate    } ).then(data => {
            if(data){           
                this.records = data;
                this.error = undefined;
                this.notFound = '';
                if(this.records == ''){
                    this.notFound = 'There is not vendor fond related to search criteria';
                }
     
               }else{
                   this.error = error;
                   this.data=undefined;
               }
       
    })
    .catch(error => {

    });


     }
 
    handlsearchtype(event){
       this.currentType  = event.target.value; 
    }
   

        // Used to sort the 'Age' column
        sortBy(field, reverse, primer) {
            const key = primer
                ? function(x) {
                      return primer(x[field]);
                  }
                : function(x) {
                      return x[field];
                  };
    
            return function(a, b) {
                a = key(a);
                b = key(b);
                return reverse * ((a > b) - (b > a));
            };
        }
    
        onHandleSort(event) {
            const { fieldName: sortedBy, sortDirection } = event.detail;
            const cloneData = [...this.records];
    
            cloneData.sort(this.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1));
            this.records = cloneData;
            this.sortDirection = sortDirection;
            this.sortedBy = sortedBy;
        }






}