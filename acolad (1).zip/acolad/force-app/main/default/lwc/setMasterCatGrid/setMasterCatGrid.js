import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import callupdateMasterCatGrid from '@salesforce/apex/MasterCatGridManager.updateMasterCatGrid'
export default class SetMasterCatGrid extends NavigationMixin(LightningElement) {
@api recordId;
showFooter ;
selectedCatGrid;
confirmed = false ;
showSubmit = false;
progress = 0 ;
isProgressing = false;
get showDiv(){
    return this.showFooter ;
}

handleAction() {
    if(this.showFooter == true){
        this.showFooter = false ;
    }else {
        this.showFooter =true ;
    }
    }

    handleChange(event) {
    console.log("You selected an account: " + event.detail.value[0]); 
    this.selectedCatGrid = event.detail.value[0] ;
    this.confirmed = false;
    this.showSubmit = true ;

}

get showSubmit(){
    return this.showSubmit;
}

handleClick(){

    if(!this.selectedCatGrid){
        this.selectedCatGrid =null ;
    }
    this.toggleProgress();        
    callupdateMasterCatGrid( { accountId: this.recordId ,catGridId : this.selectedCatGrid , confirmed : this.confirmed  } ).then(result => {

        console.log('result'+result);
        if(result != 'OK' ) {
        this.toggleProgress();
        console.log('result should be confirmed!');
        this.showToastAndshowDetails(result) ;
        //this.showToast('info','Your Account Have already a master cat Grid are you sure to averwrite it ?');
        this.confirmed = true;
        //this.navigateToRecordPage() ;
        }else if(result == 'OK'){
        this.progress = 100 ;
        console.log('result is OK !');
        this.confirmed = false;
        this.showToast('info','Your master cat grid has been succefully updated, please refresh this page!');
        }
    })
    .catch(error => {
        this.showSubmit = true ;
        this.toggleProgress();
        console.log("got error callFactureDoc ", name , error);
        if(error.body.pageErrors && error.body.pageErrors[0].message ){
        error =  error.body.pageErrors[0].message ;
        }else if (error.body.message){
        error =  error.body.message ;
        }
    
        this.showToast('error','Error occured when move account '+error);
    });




    
}



showToastAndshowDetails(recordIdtoShow) {
    this[NavigationMixin.GenerateUrl]({
        type: 'standard__recordPage',
        attributes: {
            recordId: recordIdtoShow,
            actionName: 'view',
        },
    }).then(url => {
        const event = new ShowToastEvent({
            "title": "Update Master cat Grid",
            "message": "Your Account Have already a master cat Grid are you sure to overwrite it ? {1}",
            "messageData": [
                'Salesforce',
                {
                    url,
                    label: '"Click here to see details" '
                }
            ]
        });
        this.dispatchEvent(event);
    });

}



showToast(variant,message) {
    const event = new ShowToastEvent({
        title: 'Update Master cat Grid',
        message: message,
        variant : variant,
    });
    this.dispatchEvent(event);
}



toggleProgress() {
    if (this.isProgressing) {
        // stop
        this.progress  = 0 ;
        this.isProgressing = false;
        clearInterval(this._interval);
    } else {
        // start
        this.isProgressing = true;
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this._interval = setInterval(() => {
            this.progress = this.progress > 60 ? this.progress : this.progress + 7;
        }, 200);
    }
}

}